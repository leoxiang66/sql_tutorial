UPDATE suppliers
set information = "Supplier C" 
where supplier_id = 1

