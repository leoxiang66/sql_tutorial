UPDATE promotions
set description = "Save up to 80% on your purchases" 
where promotion_id = 1

