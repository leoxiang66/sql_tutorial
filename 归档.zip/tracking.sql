SELECT * from 
inventory INNER JOIN suppliers on inventory.supplier_id = suppliers.supplier_id