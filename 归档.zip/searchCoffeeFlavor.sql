SELECT * from inventory
where item_name = "Espresso"