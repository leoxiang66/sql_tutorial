UPDATE customers
set name = "Leo Doe" 
where customer_id = 1

