select * from customer_interactions
ORDER BY interaction_date DESC